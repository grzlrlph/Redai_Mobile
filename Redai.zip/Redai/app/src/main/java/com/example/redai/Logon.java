package com.example.redai;

import static com.example.redai.R.id.btnCriarConta_logon;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import java.util.Objects;

public class Logon extends AppCompatActivity {

    private ImageButton btnEntrar_logon;
    private ImageButton btnCriarConta_logon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnEntrar_logon = findViewById(R.id.btnEntrar_logon);
        btnCriarConta_logon = findViewById(R.id.btnCriarConta_logon);

        Cadastro();


    }

    private void Cadastro() {
        btnCriarConta_logon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentCadastro = new Intent(Logon.this, Sign_in1.class);
                startActivity(intentCadastro);
            }
        });
    }
}