
package com.example.redai;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageButton;

public class Sign_in2 extends AppCompatActivity {

    private Animation animFadein;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in2);

      animFadein = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.fade_in);
      ImageButton btnVoltarTela = findViewById(R.id.btnVoltar_Cadastro2);

      btnVoltarTela.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View view) {
              Intent intentVoltaTela2 = new Intent(Sign_in2.this, Sign_in1.class);
              startActivity(intentVoltaTela2);
          }
      });




    }
}