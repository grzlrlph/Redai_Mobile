package com.example.redai;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class Sign_in1 extends AppCompatActivity {

    private ImageButton btnProximo;
    private ImageButton btnVoltar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in1);
        btnVoltar = findViewById(R.id.btnVoltar_Cadastro);
        btnProximo = findViewById(R.id.btnProximo_Cadastro);

        voltaTela();
        proximaTela();
    }

    private void voltaTela() {
        btnVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentVoltar = new Intent(Sign_in1.this, Logon.class);
                startActivity(intentVoltar);
            }
        });
    }
    private void proximaTela() {
        btnProximo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentProximaTela = new Intent(Sign_in1.this, Sign_in2.class);
                startActivity(intentProximaTela);
            }
        });
    }
}